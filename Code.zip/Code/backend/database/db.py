from pymongo.mongo_client import MongoClient
from fastapi import HTTPException

# Notice there is only ONE quote at the beginning and ONE at the end!
MONGO_URI = "mongodb+srv://guest_db_user:Gokul%26raj2552@cluster0.m5xq4iz.mongodb.net/?appName=Cluster0"

def get_db():
    try:
        # Create a new client and connect to the server
        client = MongoClient(MONGO_URI)
        
        # Send a ping to confirm a successful connection
        client.admin.command('ping')
        
        # Return the specific database instance we want to use
        db = client.financial_copilot
        return db
    except Exception as err:
        print(f"Database connection failed: {err}")
        raise HTTPException(status_code=500, detail="Database connection failed")
