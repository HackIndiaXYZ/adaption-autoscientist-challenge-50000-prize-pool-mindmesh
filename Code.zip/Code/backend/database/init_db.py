from pymongo.mongo_client import MongoClient

# Replace <db_password> with your actual MongoDB password
MONGO_URI = "mongodb+srv://guest_db_user:Gokul%26raj2552@cluster0.m5xq4iz.mongodb.net/?appName=Cluster0"

def setup_database():
    print("Connecting to MongoDB...")
    client = MongoClient(MONGO_URI)
    db = client.financial_copilot

    print("Creating unique index for User Emails...")
    # This replaces: email VARCHAR(255) NOT NULL UNIQUE
    db.users.create_index("email", unique=True)

    print("Creating collections...")
    # We don't HAVE to do this, but it makes them show up in your MongoDB Atlas dashboard immediately!
    collections_to_create = [
        "users", 
        "financial_accounts", 
        "transactions", 
        "portfolio_holdings", 
        "goals", 
        "chat_history", 
        "loans"
    ]
    
    existing_collections = db.list_collection_names()
    
    for collection in collections_to_create:
        if collection not in existing_collections:
            db.create_collection(collection)
            print(f" -> Created '{collection}' collection.")
        else:
            print(f" -> '{collection}' already exists.")

    print("\nDatabase setup complete! You are ready to run main.py!")

if __name__ == "__main__":
    setup_database()
