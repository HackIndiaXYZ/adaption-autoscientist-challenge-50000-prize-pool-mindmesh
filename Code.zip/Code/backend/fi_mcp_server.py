from mcp.server.fastmcp import FastMCP
from pymongo.mongo_client import MongoClient
from bson.objectid import ObjectId
import json

# 1. Initialize the MCP Server (Simulating Fi's Architecture)
mcp = FastMCP("FinCoPilot_Fi_MCP")

# Replace <db_password> with your actual MongoDB password
MONGO_URI = "mongodb+srv://guest_db_user:<db_password>@cluster0.m5xq4iz.mongodb.net/?appName=Cluster0"

def get_db():
    client = MongoClient(MONGO_URI)
    return client.financial_copilot

def format_doc(doc):
    """Helper to convert MongoDB ObjectId to string for JSON serialization"""
    if doc and '_id' in doc:
        doc['id'] = str(doc.pop('_id'))
    return doc

# 2. Define AI Tools using the @mcp.tool() decorator
@mcp.tool()
def get_financial_summary(user_id: str) -> str:
    """Gets a summary of the user's total income, expenses, and net balance."""
    db = get_db()
    try:
        txns = list(db.transactions.find({"user_id": user_id}, {"amount": 1, "transaction_type": 1}))
        
        income = sum(float(t.get('amount', 0)) for t in txns if t.get('transaction_type') == 'CREDIT')
        expense = sum(float(t.get('amount', 0)) for t in txns if t.get('transaction_type') == 'DEBIT')
        
        return json.dumps({
            "total_income": income,
            "total_expenses": expense,
            "net_balance": income - expense
        })
    except Exception as e:
        return f"Error: {str(e)}"

@mcp.tool()
def get_savings_goals(user_id: str) -> str:
    """Fetches the user's active financial savings goals. Use this to find the goal_id before updating."""
    db = get_db()
    try:
        goals = list(db.goals.find({"user_id": user_id}))
        
        formatted_goals = []
        for g in goals:
            g = format_doc(g)
            formatted_goals.append({
                "goal_id": g['id'], # Map id to goal_id for the AI
                "goal_name": g.get('goal_name', ''),
                "target_amount": float(g.get('target_amount', 0)),
                "current_amount": float(g.get('current_amount', 0)),
                "target_date": str(g.get('target_date', ''))
            })
        
        return json.dumps(formatted_goals)
    except Exception as e:
        return f"Error: {str(e)}"

@mcp.tool()
def add_funds_to_goal(goal_id: str, amount: float) -> str:
    """Adds money to a specific savings goal. ALWAYS use get_savings_goals FIRST to find the correct goal_id."""
    db = get_db()
    try:
        result = db.goals.update_one(
            {"_id": ObjectId(goal_id)},
            {"$inc": {"current_amount": float(amount)}}
        )
        if result.modified_count > 0:
            return f"Successfully added Rs. {amount} to goal ID {goal_id}."
        else:
            return f"Error: Could not find goal with ID {goal_id}."
    except Exception as e:
        return f"Error updating goal: {str(e)}"

if __name__ == "__main__":
    # Start the MCP server using Standard Input/Output (stdio)
    mcp.run()