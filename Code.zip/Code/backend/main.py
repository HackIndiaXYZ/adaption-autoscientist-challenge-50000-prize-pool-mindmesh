from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import pandas as pd
import csv
import os
import shutil
import json
import time
import re
import bcrypt
import uvicorn
import hashlib # Add this near your other imports at the top
# --- CHANGED FROM MYSQL TO MONGODB ---
from database.db import get_db
from bson.objectid import ObjectId
# -------------------------------------
from fastapi.responses import StreamingResponse
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
import yfinance as yf
from datetime import datetime, timedelta
import requests
import random
import pyotp
import qrcode
import base64
from io import BytesIO
from typing import Optional
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
# --- LANGCHAIN & GROQ IMPORTS ---
from groq import Groq
from langchain_groq import ChatGroq
from langchain_openai import ChatOpenAI                  
from langchain_google_genai import ChatGoogleGenerativeAI 
from langchain_anthropic import ChatAnthropic            
from langchain_core.tools import tool
from langchain_classic.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate
from langchain_community.tools.tavily_search import TavilySearchResults

# Set your API Key (or add it to your .env file)
os.environ["TAVILY_API_KEY"] = "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"
FINNHUB_API_KEY = "d76eml9r01qm4b7u0e4gd76eml9r01qm4b7u0e50"
# --------------------------------

app = FastAPI(title="FinCoPilot Secure API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- API KEYS & CLIENTS ---
GROQ_API_KEY = "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"
GROQ_MODEL = "llama-3.3-70b-versatile"

OPENAI_API_KEY = "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"
GEMINI_API_KEY = "AIzaSyA2kfhJNr8sQsdmUP8eIELp7hJSJMql5_o"
ANTHROPIC_API_KEY = "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"
GROK_API_KEY = "xai-oSukxgWdqA3csrdmoMBux8cgHgCOl3AHj0bx17eEZuUdYAWyb1yySLe98pcpZo8D9SI0fg7Oia5lZndL"

raw_groq_client = Groq(api_key=GROQ_API_KEY)
# --------------------------

# --- NEW MONGODB HELPER FUNCTIONS ---
def format_doc(doc):
    """Converts MongoDB ObjectId to a string 'id' for the React frontend"""
    if doc and '_id' in doc:
        doc['id'] = str(doc.pop('_id'))
    return doc

def format_docs(docs):
    return [format_doc(doc) for doc in docs]
# ------------------------------------

class UserSignup(BaseModel):
    name: str
    email: str
    password: str
    profession: str = "Not Specified"
    monthly_salary: float = 0.0
    marital_status: str = "Single"
    family_size: int = 1

class UserUpdate(BaseModel):
    name: str
    profession: str
    monthly_salary: float
    marital_status: str
    family_size: int
    custom_budgets: dict = {}
    two_factor_enabled: bool = False
    two_factor_secret: Optional[str] = None 

class UserLogin(BaseModel):
    email: str
    password: str
    two_factor_code: Optional[str] = None 

# ALL IDs CHANGED TO STR FOR MONGODB
class GoalCreate(BaseModel):
    user_id: str 
    goal_name: str
    target_amount: float
    target_date: str

class GoalUpdate(BaseModel):
    goal_id: str 
    add_amount: float

class PortfolioAdd(BaseModel):
    user_id: str 
    symbol: str
    qty: float
    price: float
    category: str = "Equity"

class LoanCreate(BaseModel):
    user_id: str 
    loan_name: str
    principal_amount: float
    interest_rate: float
    duration_months: int
    emi_amount: float
    start_date: str

class LoanPayment(BaseModel):
    loan_id: str 
    payment_amount: float  
    interest_amount: float = 0.0  

class GoalEdit(BaseModel):
    goal_name: str
    target_amount: float
    target_date: str

class PortfolioEdit(BaseModel):
    quantity: float
    price: float

class LoanEdit(BaseModel):
    loan_name: str
    principal_amount: float
    interest_rate: float
    duration_months: int
    emi_amount: float
    start_date: str    

# ==========================================
# AUTHENTICATION & DASHBOARD ENDPOINTS
# ==========================================
@app.post("/api/signup")
def signup_user(user: UserSignup):
    db = get_db()
    if db.users.find_one({"email": user.email}):
        raise HTTPException(status_code=400, detail="Email already registered")
    
    hashed_pw = bcrypt.hashpw(user.password.encode('utf-8'), bcrypt.gensalt())
    
    new_user = {
        "name": user.name,
        "email": user.email,
        "password_hash": hashed_pw.decode('utf-8'),
        "profession": user.profession,
        "monthly_salary": user.monthly_salary,
        "marital_status": user.marital_status,
        "family_size": user.family_size,
        "custom_budgets": "{}",
        "two_factor_enabled": False,
        "two_factor_secret": None,
        "created_at": datetime.now()
    }
    
    result = db.users.insert_one(new_user)
    return {"status": "success", "user": {"id": str(result.inserted_id), "name": user.name, "email": user.email}}

@app.post("/api/login")
def login_user(user: UserLogin):
    db = get_db()
    db_user = db.users.find_one({"email": user.email})
    
    # 1. Verify Password
    if not db_user or not bcrypt.checkpw(user.password.encode('utf-8'), db_user['password_hash'].encode('utf-8')):
        raise HTTPException(status_code=401, detail="Invalid email or password")
        
    # 2. Check if 2FA is enabled
    if db_user.get('two_factor_enabled'):
        if not user.two_factor_code:
            return {"status": "2fa_required", "message": "Please enter your Authenticator code."}
            
        totp = pyotp.TOTP(db_user['two_factor_secret'])
        if not totp.verify(user.two_factor_code):
            raise HTTPException(status_code=401, detail="Invalid 2FA code. Please try again.")

    # 3. Success!
    return {"status": "success", "user": {"id": str(db_user['_id']), "name": db_user['name'], "email": db_user['email']}}

@app.put("/api/users/{user_id}")
def update_user_profile(user_id: str, profile: UserUpdate):
    db = get_db()
    db.users.update_one(
        {"_id": ObjectId(user_id)},
        {"$set": {
            "name": profile.name,
            "profession": profile.profession,
            "monthly_salary": profile.monthly_salary,
            "marital_status": profile.marital_status,
            "family_size": profile.family_size,
            "custom_budgets": json.dumps(profile.custom_budgets),
            "two_factor_enabled": profile.two_factor_enabled,
            "two_factor_secret": profile.two_factor_secret
        }}
    )
    return {"status": "success"}

@app.get("/api/users/{user_id}")
def get_user_profile(user_id: str):
    db = get_db()
    user_data = db.users.find_one({"_id": ObjectId(user_id)})
    if user_data:
        user_data = format_doc(user_data)
        user_data['monthly_salary'] = float(user_data.get('monthly_salary', 0))
        user_data['two_factor_enabled'] = bool(user_data.get('two_factor_enabled', False))
        user_data['custom_budgets'] = json.loads(user_data.get('custom_budgets', '{}')) 
        
        user_data.pop('password_hash', None)
        return {"status": "success", "data": user_data}
    return {"status": "error", "message": "User not found"}

@app.get("/api/dashboard")
def get_dashboard_data(user_id: str):
    db = get_db()
    txns = list(db.transactions.find({"user_id": user_id}).sort([("transaction_date", -1), ("_id", -1)]))
    return {"status": "success", "data": format_docs(txns)}

@app.get("/api/user/is-new/{user_id}")
def check_new_user(user_id: str):
    db = get_db()
    count = db.transactions.count_documents({"user_id": user_id})
    is_new = count == 0
    return {"status": "success", "is_new": is_new}

# ==========================================
# CSV PARSING & UPLOAD LOGIC
# ==========================================

def parse_csv(file_path, previous_balance=None):
    try:
        # 1. Read the first 35 lines to send to the AI
        head_lines = []
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            for _ in range(35):
                line = f.readline()
                if not line: break
                head_lines.append(line)
                
        csv_snippet = "".join(head_lines)
        
        # 2. Ask Groq AI to identify ALL columns, including the Balance column
        prompt = f"""You are a financial data parsing AI. Look at the following CSV snippet.
        Identify the EXACT column names used by this bank for the transaction table.
        Return ONLY a valid JSON object.

        CRITICAL RULE: Return the exact text as it appears in the CSV.
        
        {{
          "date_col": "<exact name>",
          "desc_col": "<exact name for description/remarks/particulars>",
          "debit_col": "<exact name for debit/withdrawal>",
          "credit_col": "<exact name for credit/deposit>",
          "balance_col": "<exact name for running balance>"
        }}
        
        CSV Data:
        {csv_snippet}
        """
        
        print("[AI] Analyzing bank statement format...")
        response = raw_groq_client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1,
            response_format={"type": "json_object"}
        )
        
        mapping = json.loads(response.choices[0].message.content)
        print(f"[AI] Identified Columns: {mapping}")
        
        target_date = str(mapping.get('date_col', '')).strip().lower()
        target_debit = str(mapping.get('debit_col', '')).strip().lower()

        # 3. Read the FULL CSV into Pandas without headers
        df_raw = pd.read_csv(file_path, header=None, dtype=str)
        
        # 4. Use Python to reliably find the exact header row
        header_idx = -1
        for idx, row in df_raw.iterrows():
            row_str = " ".join([str(val).strip().lower() for val in row.values])
            if target_date in row_str and (target_debit in row_str or 'amount' in row_str or 'withdrawal' in row_str):
                header_idx = idx
                break
                
        if header_idx == -1:
            print("CRITICAL: Could not locate the header row based on AI mappings.")
            return None
            
        print(f"[SYSTEM] Header reliably found at index {header_idx}")

        # 5. Set the verified header and slice the dataframe
        df = df_raw.iloc[header_idx + 1:].copy()
        df.columns = df_raw.iloc[header_idx].astype(str).str.strip()
        df.reset_index(drop=True, inplace=True)

        def get_actual_col(expected_name):
            if not expected_name or expected_name == "null": return None
            expected_name = str(expected_name).strip().lower()
            for col in df.columns:
                if expected_name == str(col).strip().lower(): return col
            for col in df.columns:
                if expected_name in str(col).strip().lower() or str(col).strip().lower() in expected_name: return col
            return None

        # 6. Extract the matched columns
        date_col = get_actual_col(mapping.get('date_col'))
        desc_col = get_actual_col(mapping.get('desc_col'))
        debit_col = get_actual_col(mapping.get('debit_col'))
        credit_col = get_actual_col(mapping.get('credit_col'))
        balance_col = get_actual_col(mapping.get('balance_col')) # NEW: Grab the balance column

        if not date_col:
            print("CRITICAL: Final date column mapping failed.")
            return None

        std_df = pd.DataFrame()
        std_df['transaction_date'] = df[date_col]
        std_df['raw_description'] = df[desc_col] if desc_col else "Unknown Transaction"

        def clean_amount(val):
            if pd.isna(val) or str(val).strip().lower() in ['nan', 'none', 'null', '']: return 0.0
            clean_val = re.sub(r'[^\d.]', '', str(val))
            try:
                return float(clean_val) if clean_val else 0.0
            except:
                return 0.0

        std_df['debit_amount'] = df[debit_col].apply(clean_amount) if debit_col else 0.0
        std_df['credit_amount'] = df[credit_col].apply(clean_amount) if credit_col else 0.0
        std_df['provided_balance'] = df[balance_col].apply(clean_amount) if balance_col else 0.0
        
        std_df['amount'] = std_df['debit_amount'] + std_df['credit_amount']
        std_df['transaction_type'] = std_df.apply(lambda row: 'DEBIT' if row['debit_amount'] > 0 else 'CREDIT', axis=1)

        # Clean empty rows
        std_df = std_df.dropna(subset=['transaction_date'])
        std_df = std_df[std_df['transaction_date'].astype(str).str.strip() != '']
        std_df = std_df[std_df['transaction_date'].astype(str).str.lower() != 'nan']
        std_df = std_df[std_df['amount'] > 0]
        std_df.reset_index(drop=True, inplace=True)

        # 7. THE REVERSE-ENGINEERING TRICK FOR OPENING BALANCES
        opening_balance = previous_balance if previous_balance is not None else 0.0
        
        # ONLY do this if previous_balance is None (meaning it's the very first time uploading this bank/account)
        if previous_balance is None and not std_df.empty:
            first_row = std_df.iloc[0]
            first_provided_balance = float(first_row.get('provided_balance', 0.0))
            
            # If the bank provided a running balance, calculate backwards to find the true starting balance!
            if first_provided_balance > 0:
                if first_row['transaction_type'] == 'CREDIT':
                    opening_balance = first_provided_balance - first_row['amount']
                else:
                    opening_balance = first_provided_balance + first_row['amount']
            else:
                # Fallback text scan just in case the balance column is missing
                for idx, row in df_raw.head(header_idx + 15).iterrows():
                    row_str = " ".join([str(val).strip().lower() for val in row.values])
                    if 'opening balance' in row_str or 'brought forward' in row_str or 'clear balance' in row_str:
                        for val in row.values:
                            val_cleaned = re.sub(r'[^\d.-]', '', str(val))
                            if val_cleaned.replace('.','',1).isdigit() and float(val_cleaned) > 0:
                                opening_balance = float(val_cleaned)
                                break
                        if opening_balance > 0: break

        # 8. Calculate Running Balances
        if previous_balance is None and opening_balance != 0 and not std_df.empty:
            # We insert the Opening Balance row ONLY for new accounts
            ob_type = 'CREDIT' if opening_balance > 0 else 'DEBIT'
            ob_row = pd.DataFrame([{
                'transaction_date': std_df.iloc[0]['transaction_date'],
                'raw_description': 'Initial Opening Balance',
                'amount': abs(opening_balance),
                'transaction_type': ob_type,
                'provided_balance': abs(opening_balance)
            }])
            std_df = pd.concat([ob_row, std_df], ignore_index=True)
            current_balance = 0.0 
        else:
            # For subsequent uploads, we just continue counting from the last known balance
            current_balance = opening_balance

        running_balances = []
        for index, row in std_df.iterrows():
            if row['transaction_type'] == 'CREDIT':
                current_balance += row['amount']
            else:
                current_balance -= row['amount']
            running_balances.append(round(current_balance, 2))

        std_df['calculated_balance'] = running_balances
        return std_df[['transaction_date', 'raw_description', 'amount', 'transaction_type', 'calculated_balance']]

    except Exception as e:
        print(f"AI CSV Parsing Error: {e}")
        return None

    df.columns = [str(col).lower().replace('\n', ' ').strip() for col in df.columns]
    
    df.rename(columns={
        'date': 'transaction_date',
        'remarks': 'raw_description',
        'withdrawals': 'debit_amount',
        'deposits': 'credit_amount',
        'balance': 'raw_balance'
    }, inplace=True)
    
    opening_balance = 0.0
    is_first_upload = False  
    
    if previous_balance is not None:
        opening_balance = previous_balance
    else:
        is_first_upload = True
        for idx, row in df.head(15).iterrows():
            row_str = " ".join(str(val).lower() for val in row.values)
            if 'opening balance' in row_str or 'brought forward' in row_str:
                if 'raw_balance' in df.columns:
                    val = str(row['raw_balance'])
                    val_cleaned = re.sub(r'[^\d.-]', '', val)
                    try:
                        opening_balance = float(val_cleaned)
                        break
                    except ValueError:
                        pass

    if 'debit_amount' in df.columns and 'credit_amount' in df.columns:
        df['debit_amount'] = pd.to_numeric(df['debit_amount'].astype(str).str.replace(r'[^\d.]', '', regex=True), errors='coerce').fillna(0)
        df['credit_amount'] = pd.to_numeric(df['credit_amount'].astype(str).str.replace(r'[^\d.]', '', regex=True), errors='coerce').fillna(0)
        
        df['amount'] = df['debit_amount'] + df['credit_amount']
        df['transaction_type'] = df.apply(lambda row: 'DEBIT' if row['debit_amount'] > 0 else 'CREDIT', axis=1)
    else: 
        print("Missing required amount columns.")
        return None

    if 'transaction_date' not in df.columns: return None
    if 'raw_description' not in df.columns: df['raw_description'] = "Unknown Transaction"
    df['raw_description'] = df['raw_description'].fillna("Unknown Transaction")
    
    df = df.dropna(subset=['transaction_date'])
    df = df[df['transaction_date'].astype(str).str.strip() != '']
    df = df[df['amount'] > 0]
    
    if is_first_upload and opening_balance != 0 and not df.empty:
        first_date = df.iloc[0]['transaction_date']
        ob_type = 'CREDIT' if opening_balance > 0 else 'DEBIT'
        
        ob_row = pd.DataFrame([{
            'transaction_date': first_date,
            'raw_description': 'Initial Opening Balance',
            'amount': abs(opening_balance),
            'transaction_type': ob_type
        }])
        
        df = pd.concat([ob_row, df], ignore_index=True)
        current_balance = 0.0
    else:
        current_balance = opening_balance
    
    running_balances = []

    for index, row in df.iterrows():
        if row['transaction_type'] == 'CREDIT':
            current_balance += row['amount']
        else:
            current_balance -= row['amount']
        running_balances.append(round(current_balance, 2))

    df['calculated_balance'] = running_balances
    
    return df[['transaction_date', 'raw_description', 'amount', 'transaction_type', 'calculated_balance']]

# --- UPGRADED AI CATEGORIZATION ---
def categorize_batch(txn_data_list):
    if not txn_data_list: return []
    
    # We now send the Description, Amount, AND Type to the AI for far greater accuracy
    prompt = "Analyze these bank transactions. Assign the most accurate category from: [Dining, Groceries, Utilities, Salary, Income, Transfer, Entertainment, Shopping, Healthcare, Transport, Investment, Subscriptions, EMI/Loan, Miscellaneous]. Clean the description to be human-readable.\n\nRespond ONLY with a valid JSON array. Format: [{\"category\": \"...\", \"clean_description\": \"...\"}]\n\n"
    
    for i, txn in enumerate(txn_data_list):
        prompt += f"{i}. Desc: {txn['desc']} | Amount: Rs.{txn['amount']} | Type: {txn['type']}\n"

    try:
        response = raw_groq_client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1
        )
        text = response.choices[0].message.content.strip()
        match = re.search(r'\[.*\]', text, re.DOTALL)
        if match: text = match.group(0)
        results = json.loads(text)
        return results if len(results) == len(txn_data_list) else [{"category": "Miscellaneous", "clean_description": t['desc']} for t in txn_data_list]
    except Exception as e:
        print(f"Batch AI Error: {e}")
        return [{"category": "Miscellaneous", "clean_description": t['desc']} for t in txn_data_list]

# --- UPGRADED UPLOAD WITH DUPLICATE PREVENTION ---
@app.post("/api/upload")
async def upload_statement(
    user_id: str = Form(...), 
    bank_name: str = Form(...),          
    account_type: str = Form(...),       
    file: UploadFile = File(...)
):
    temp_file_path = f"temp_{file.filename}"
    with open(temp_file_path, "wb") as buffer: shutil.copyfileobj(file.file, buffer)

    try:
        db = get_db()
        
        # FETCH EXISTING TRANSACTION FINGERPRINTS TO PREVENT DUPLICATES
        existing_txns = list(db.transactions.find(
            {"user_id": user_id, "bank_name": bank_name}, 
            {"txn_fingerprint": 1}
        ))
        existing_fingerprints = {t.get("txn_fingerprint") for t in existing_txns if t.get("txn_fingerprint")}

        # FETCH PREVIOUS BALANCE
        last_record = list(db.transactions.find({
            "user_id": user_id, "bank_name": bank_name, "account_type": account_type
        }).sort([("transaction_date", -1), ("_id", -1)]).limit(1))
        previous_balance = float(last_record[0]['balance']) if last_record else None

        df = parse_csv(temp_file_path, previous_balance)
        if df is None or df.empty:
            raise HTTPException(status_code=400, detail="Unrecognized CSV format.")
            
        rows_processed = 0
        duplicates_skipped = 0
        batch_size = 30 
        
        for start_idx in range(0, len(df), batch_size):
            batch_df = df.iloc[start_idx:start_idx+batch_size]
            
            # Prepare rich data for the upgraded AI categorizer
            ai_input_data = []
            for _, row in batch_df.iterrows():
                ai_input_data.append({
                    "desc": row['raw_description'], 
                    "amount": row['amount'], 
                    "type": row['transaction_type']
                })
                
            ai_results = categorize_batch(ai_input_data)
            docs_to_insert = []
            
            for i, (index, row) in enumerate(batch_df.iterrows()):
                parsed_date = pd.to_datetime(row['transaction_date'], errors='coerce')
                if pd.isna(parsed_date): continue 
                date_str = parsed_date.strftime('%Y-%m-%d')
                
                raw_desc = str(row['raw_description']).strip()
                amt = float(row['amount'])
                txn_type = str(row['transaction_type'])
                
                # GENERATE UNIQUE FINGERPRINT
                unique_string = f"{user_id}_{bank_name}_{date_str}_{raw_desc}_{amt}_{txn_type}"
                txn_fingerprint = hashlib.md5(unique_string.encode('utf-8')).hexdigest()
                
                # SKIP IF IT ALREADY EXISTS IN THE DATABASE
                if txn_fingerprint in existing_fingerprints:
                    duplicates_skipped += 1
                    continue
                    
                category = ai_results[i]['category'] if i < len(ai_results) else "Miscellaneous"
                clean_desc = ai_results[i]['clean_description'] if i < len(ai_results) else raw_desc
                
                docs_to_insert.append({
                    "user_id": user_id,
                    "bank_name": bank_name,          
                    "account_type": account_type,    
                    "transaction_date": date_str,
                    "raw_description": raw_desc,
                    "clean_description": clean_desc,
                    "category": category,
                    "amount": amt,
                    "transaction_type": txn_type,
                    "balance": float(row['calculated_balance']),
                    "txn_fingerprint": txn_fingerprint,  # Save the fingerprint
                    "created_at": datetime.now()
                })
                rows_processed += 1
            
            if docs_to_insert:
                db.transactions.insert_many(docs_to_insert)
                db.financial_accounts.update_one(
                    {"user_id": user_id, "bank_name": bank_name, "account_type": account_type},
                    {"$set": {"last_updated": datetime.now()}},
                    upsert=True
                )
            time.sleep(1) 
        
        msg = f"Successfully processed {rows_processed} new transactions."
        if duplicates_skipped > 0:
            msg += f" (Skipped {duplicates_skipped} duplicate entries)."
            
        return {"status": "success", "message": msg}
        
    except Exception as e:
        print(f"CRITICAL UPLOAD ERROR: {str(e)}")
        raise HTTPException(status_code=400, detail=f"Server Error during parsing: {str(e)}")
    finally:
        if os.path.exists(temp_file_path): os.remove(temp_file_path)
        
# ==========================================
# LANGCHAIN AI AGENT & TOOLS
# ==========================================

@tool
def fetch_user_financial_summary(user_id: str) -> dict:
    """Gets a summary of the user's total income, expenses, and net balance. Use this when the user asks about their overall balance or spending."""
    print(f"[LANGCHAIN AGENT] Fetching summary for user {user_id}...")
    db = get_db()
    txns = list(db.transactions.find({"user_id": user_id}, {"amount": 1, "transaction_type": 1}))
    income = sum(float(t.get('amount', 0)) for t in txns if t.get('transaction_type') == 'CREDIT')
    expense = sum(float(t.get('amount', 0)) for t in txns if t.get('transaction_type') == 'DEBIT')
    return {"total_income": income, "total_expenses": expense, "net_balance": income - expense}

@tool
def fetch_user_savings_goals(user_id: str) -> list:
    """Fetches the user's active financial savings goals. Use this to find the goal_id before updating or deleting."""
    print(f"[LANGCHAIN AGENT] Fetching goals for user {user_id}...")
    db = get_db()
    goals = list(db.goals.find({"user_id": user_id}).sort("target_date", 1))
    formatted_goals = []
    for idx, g in enumerate(goals):
        g = format_doc(g)
        g['display_number'] = f"Goal {idx + 1}"
        g['amount_remaining'] = float(g.get('target_amount', 0)) - float(g.get('current_amount', 0))
        formatted_goals.append(g)
    return formatted_goals

@tool
def add_funds_to_goal(goal_id: str, amount: float) -> str:
    """Adds money to a specific savings goal. ALWAYS use fetch_user_savings_goals FIRST to find the correct goal_id before calling this tool."""
    print(f"[LANGCHAIN AGENT] Adding Rs. {amount} to goal {goal_id}...")
    db = get_db()
    result = db.goals.update_one({"_id": ObjectId(goal_id)}, {"$inc": {"current_amount": float(amount)}})
    if result.modified_count > 0:
        return f"Successfully added Rs. {amount} to goal ID {goal_id}."
    return f"Error updating goal. ID {goal_id} not found."

@tool
def create_new_goal(user_id: str, goal_name: str, target_amount: float, target_date: str) -> str:
    """Creates a new financial savings goal for the user. target_date MUST be in YYYY-MM-DD format."""
    print(f"[LANGCHAIN AGENT] Creating new goal '{goal_name}' for user {user_id}...")
    db = get_db()
    db.goals.insert_one({
        "user_id": user_id, "goal_name": goal_name, 
        "target_amount": float(target_amount), "current_amount": 0.0, 
        "target_date": target_date, "created_at": datetime.now()
    })
    return f"Successfully created new goal '{goal_name}' with target Rs. {target_amount} by {target_date}."

@tool
def delete_existing_goal(goal_id: str) -> str:
    """Deletes a specific savings goal. ALWAYS use fetch_user_savings_goals FIRST to find the correct goal_id before calling this tool."""
    print(f"[LANGCHAIN AGENT] Deleting goal {goal_id}...")
    db = get_db()
    result = db.goals.delete_one({"_id": ObjectId(goal_id)})
    if result.deleted_count > 0:
        return f"Successfully deleted goal ID {goal_id}."
    return "Goal not found."

@tool
def fetch_spending_by_category(user_id: str) -> dict:
    """Gets a detailed breakdown of the user's expenses grouped by category."""
    print(f"[LANGCHAIN AGENT] Fetching spending categories for user {user_id}...")
    db = get_db()
    pipeline = [
        {"$match": {"user_id": user_id, "transaction_type": "DEBIT"}},
        {"$group": {"_id": "$category", "total_spent": {"$sum": "$amount"}}},
        {"$sort": {"total_spent": -1}}
    ]
    results = list(db.transactions.aggregate(pipeline))
    return {row['_id']: float(row['total_spent']) for row in results if row['_id']}

@tool
def fetch_recent_transactions(user_id: str) -> list:
    """Gets the user's 30 most recent transactions."""
    print(f"[LANGCHAIN AGENT] Fetching recent transactions for user {user_id}...")
    db = get_db()
    results = list(db.transactions.find(
        {"user_id": user_id}, 
        {"transaction_date": 1, "clean_description": 1, "category": 1, "amount": 1, "transaction_type": 1}
    ).sort([("transaction_date", -1), ("_id", -1)]).limit(30))
    return format_docs(results)

@tool
def fetch_user_portfolio(user_id: str) -> list:
    """Fetches the user's current investment portfolio."""
    print(f"[LANGCHAIN AGENT] Fetching portfolio for user {user_id}...")
    db = get_db()
    holdings = list(db.portfolio_holdings.find({"user_id": user_id}))
    formatted = []
    for h in holdings:
        h = format_doc(h)
        h['total_value'] = float(h.get('quantity', 0)) * float(h.get('current_market_price', 0))
        h['profit_loss'] = (float(h.get('current_market_price', 0)) - float(h.get('average_buy_price', 0))) * float(h.get('quantity', 0))
        formatted.append(h)
    return formatted

# --- LIVE PRICE HELPER ---
@tool
def manage_user_portfolio(user_id: str, action: str, symbol: str, name: str = "", category: str = "Equity", qty: float = 0, price: float = 0) -> str:
    """Adds, updates, or deletes an investment asset. 'action' must be 'ADD', 'UPDATE', or 'DELETE'."""
    db = get_db()
    symbol_upper = symbol.upper()
    if action.upper() == 'ADD':
        if not name:
            if category in ["Mutual Fund", "SIP"] and symbol.isdigit() and len(symbol) == 6:
                try:
                    mf_data = requests.get(f"https://api.mfapi.in/mf/{symbol}").json()
                    name = mf_data.get("meta", {}).get("scheme_name", symbol)
                except:
                    name = symbol
            else:
                try:
                    name = yf.Ticker(symbol).info.get('shortName', symbol)
                except:
                    name = symbol
                    
        db.portfolio_holdings.insert_one({
            "user_id": user_id, "asset_symbol": symbol_upper, "asset_name": name, 
            "asset_class": category, "quantity": qty, "average_buy_price": price, 
            "current_market_price": price, "last_updated": datetime.now()
        })
    elif action.upper() == 'UPDATE':
        db.portfolio_holdings.update_one(
            {"user_id": user_id, "asset_symbol": symbol_upper}, 
            {"$set": {"quantity": qty, "average_buy_price": price, "last_updated": datetime.now()}}
        )
    elif action.upper() == 'DELETE':
        db.portfolio_holdings.delete_one({"user_id": user_id, "asset_symbol": symbol_upper})
    
    return f"Portfolio successfully modified: {action} {symbol_upper}."

# --- FOREX CACHE (Live USD to INR Conversion) ---
usd_inr_rate = None
last_rate_fetch = 0

def get_usd_to_inr():
    global usd_inr_rate, last_rate_fetch
    current_time = time.time()
    
    if usd_inr_rate is None or (current_time - last_rate_fetch > 3600):
        try:
            data = yf.Ticker("INR=X").history(period="1d")
            if not data.empty:
                usd_inr_rate = float(data['Close'].iloc[-1])
                last_rate_fetch = current_time
        except Exception as e:
            print(f"Error fetching exchange rate: {e}")
            usd_inr_rate = 83.50 
            
    return usd_inr_rate or 83.50        

def get_live_price(symbol: str, asset_class: str = "Equity"):
    """Fetches real-time price using yfinance or mfapi.in and converts USD to INR."""
    try:
        if asset_class in ["Mutual Fund", "SIP"] and symbol.isdigit() and len(symbol) == 6:
            response = requests.get(f"https://api.mfapi.in/mf/{symbol}")
            if response.status_code == 200:
                data = response.json()
                if "data" in data and len(data["data"]) > 0:
                    return float(data["data"][0]["nav"]) 
                    
        ticker = yf.Ticker(symbol)
        data = ticker.history(period="1d")
        
        if not data.empty:
            price = float(data['Close'].iloc[-1])
            info = ticker.info
            currency = info.get('currency', 'Unknown')
            
            if currency == 'USD' or symbol.endswith('-USD'):
                conversion_rate = get_usd_to_inr()
                price = price * conversion_rate
                
            return round(price, 2)
            
    except Exception as e:
        print(f"Price fetch error for {symbol} ({asset_class}): {e}")
    return None

@tool
def analyze_stock_market(ticker_symbol: str) -> str:
    """Fetches real-time market data, news, and calculates numerical price projections. Auto-converts USD to INR."""
    
    # 1. FIX: Aggressively strip stray quotes and spaces the AI might add
    clean_ticker = ticker_symbol.strip().strip("'").strip('"').upper()
    print(f"[LANGCHAIN AGENT] Analyzing market & news for {clean_ticker}...")
    
    try:
        ticker = yf.Ticker(clean_ticker)
        info = ticker.info
        
        # Safe fetch of current price
        current_price = info.get('regularMarketPrice') or info.get('currentPrice')
        if current_price is None:
            hist_1d = ticker.history(period="1d")
            current_price = float(hist_1d['Close'].iloc[-1]) if not hist_1d.empty else 0.0
        else:
            current_price = float(current_price)

        currency = info.get('currency', 'INR')
        
        # Fetch history for trend calculations
        hist = ticker.history(period="1mo")
        if not hist.empty and current_price > 0:
            # 2. FIX: Force Pandas values into standard Python floats
            start_price = float(hist['Close'].iloc[0])
            end_price = float(hist['Close'].iloc[-1])
            change_pct = ((end_price - start_price) / start_price) * 100
            trend = "Bullish" if change_pct > 0 else "Bearish"
            
            std_dev = float(hist['Close'].std())
            projected_high = current_price + (std_dev * 1.5)
            projected_low = current_price - (std_dev * 1.5) 
        else:
            trend = "Stable"
            change_pct = 0.0
            projected_high = current_price
            projected_low = current_price

        # USD to INR Conversion
        if currency == 'USD' or clean_ticker.endswith('-USD'):
            rate = get_usd_to_inr() # Ensure this function exists in your code
            current_price *= rate
            projected_high *= rate
            projected_low *= rate

        # 3. FIX: Wrap Tavily in a try/except so if it fails, it doesn't crash the whole tool
        try:
            tavily_tool = TavilySearchResults(max_results=3, topic="finance", search_depth="advanced")
            search_query = f"latest financial news and analyst ratings for {clean_ticker} stock"
            news_context = tavily_tool.invoke({"query": search_query})
            formatted_news = "\n".join([f"- {res['content']}" for res in news_context])
        except Exception as news_err:
            print(f"[TOOL ERROR] Tavily search failed: {news_err}")
            formatted_news = "- Live news currently unavailable."

        return f"""
        LIVE MARKET DATA FOR {clean_ticker}:
        - Current Price: Rs. {current_price:.2f}
        - 30-Day Trend: {trend} ({change_pct:.2f}%)
        
        NUMERICAL PREDICTION (30-Day Target):
        - Expected High: Rs. {projected_high:.2f}
        - Expected Low: Rs. {projected_low:.2f}
        
        REAL-TIME NEWS:
        {formatted_news}
        """
    except Exception as e:
        print(f"[TOOL ERROR] analyze_stock_market failed: {e}")
        return f"Error fetching data for {clean_ticker}: {str(e)}"
@tool
def fetch_user_loans(user_id: str) -> list:
    """Fetches the user's active and past loans/debts."""
    print(f"[LANGCHAIN AGENT] Fetching loans for user {user_id}...")
    db = get_db()
    loans = list(db.loans.find({"user_id": user_id}))
    return format_docs(loans)

@tool
def pay_loan_principal(loan_id: str, principal_amount: float) -> str:
    """Records an EMI/principal payment towards a specific loan."""
    print(f"[LANGCHAIN AGENT] Paying Rs. {principal_amount} towards loan ID {loan_id}...")
    db = get_db()
    
    try:
        loan = db.loans.find_one({"_id": ObjectId(loan_id)})
        if not loan:
            return f"Error: No loan found with ID {loan_id}."
            
        current_balance = float(loan.get('outstanding_balance', 0))
        payment = float(principal_amount)
        if payment > current_balance:
            payment = current_balance
            
        new_balance = current_balance - payment
        
        db.loans.update_one({"_id": ObjectId(loan_id)}, {"$set": {"outstanding_balance": new_balance}})
        
        if new_balance <= 0:
            return f"SUCCESS: Paid Rs. {payment:,.2f} towards '{loan.get('loan_name', '')}'. The loan is now FULLY REPAID and the balance is Rs. 0!"
        else:
            return f"SUCCESS: Paid Rs. {payment:,.2f} towards '{loan.get('loan_name', '')}'. The new outstanding balance is Rs. {new_balance:,.2f}."
            
    except Exception as e:
        print(f"Loan Payment Error: {e}")
        return f"Database error occurred while trying to process the payment: {str(e)}"

# --- DYNAMIC AI AGENT SWITCHER ---
def get_agent_executor(model_choice: str):
    if model_choice == "ChatGPT":
        llm = ChatOpenAI(model="gpt-4o", api_key=OPENAI_API_KEY, temperature=0.2)
    elif model_choice == "Gemini":
        llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash", google_api_key=GEMINI_API_KEY, temperature=0.2)
    elif model_choice == "Claude":
        llm = ChatAnthropic(model="claude-3-opus-20240229", api_key=ANTHROPIC_API_KEY, temperature=0.2)
    else:
        llm = ChatGroq(model=GROQ_MODEL, api_key=GROQ_API_KEY, temperature=0.2)

    agent = create_tool_calling_agent(llm, mcp_tools, prompt_template)
    return AgentExecutor(agent=agent, tools=mcp_tools, verbose=True)        

# --- DYNAMIC AI AGENT SWITCHER ---
mcp_tools = [
    fetch_user_financial_summary, 
    fetch_user_savings_goals, 
    add_funds_to_goal, 
    create_new_goal, 
    delete_existing_goal,
    fetch_spending_by_category,
    fetch_recent_transactions,
    fetch_user_portfolio,   
    manage_user_portfolio,  
    analyze_stock_market,
    fetch_user_loans,
    pay_loan_principal  
]

llm = ChatGroq(model=GROQ_MODEL, api_key=GROQ_API_KEY, temperature=0.2)

SYSTEM_PROMPT = """You are FinCoPilot, an elite, autonomous AI wealth manager. You do not just provide advice; you actively manage wealth, optimize portfolios, and execute debt-reduction strategies on behalf of the user. Your tone is highly analytical, objective, and sophisticated, mirroring a top-tier hedge fund manager.

CORE DIRECTIVE & CONSTRAINTS:
1. TONE & FORMATTING: Speak with ultimate authority and professionalism. No emojis, no casual slang, no hedging. Use clean, plain text. DO NOT use asterisks (*) or markdown bolding anywhere in your response. Format all currency in Indian Rupees (e.g., Rs. 50,000).
2. CONFIDENCE: You ARE the certified financial professional. NEVER tell the user to "consult with a financial advisor." You own your algorithmic analysis and present it confidently as the definitive strategy.
3. ZERO HALLUCINATION: Base all financial calculations STRICTLY on the provided database tools. 
4. ACTIVE DATA ONLY: When summarizing loans or debts, ONLY mention loans with an outstanding balance strictly greater than 0. Completely ignore and hide any paid-off loans (balance of 0) unless the user explicitly asks for their repayment history.

STANDARD OPERATING PROCEDURES (SOPs):

SOP 1: COMPREHENSIVE NET WORTH CALCULATION
When asked for net worth or total wealth, you must calculate the TRUE Net Worth:
1. Execute 'fetch_user_financial_summary' (for liquid cash balance).
2. Execute 'fetch_user_portfolio' (for total investment asset value).
3. Execute 'fetch_user_loans' (to calculate total outstanding debt/liabilities, ignoring 0 balance loans).
4. Formula: (Cash + Investments) - Debt = True Net Worth. Present the exact breakdown and the final number clearly without asterisks.

SOP 2: DEBT VS. INVESTMENT STRATEGY (THE AVALANCHE METHOD)
When a user has extra cash and asks whether to invest or pay off loans:
1. Execute 'fetch_user_loans' and analyze both the 'interest_rate' and the 'total_interest_paid' columns.
2. Explicitly highlight how much money they have already lost to the bank (total_interest_paid). Use this data to urgently motivate them to pay down the principal.
3. If the highest loan interest rate is greater than 10%, strictly advise paying off the debt first (guaranteed tax-free return) instead of investing.
4. If the user explicitly asks to pay a loan, IMMEDIATELY execute 'pay_loan_principal' using the exact loan ID and amount requested.

SOP 3: INVESTMENT & STOCK ANALYSIS
When a user asks about investing in a specific stock:
1. Identify the correct Yahoo Finance ticker. CRITICAL: For Indian companies, you MUST append '.NS' to the ticker symbol (e.g., 'TATAMOTORS.NS', 'RELIANCE.NS', 'HDFCBANK.NS'). For US companies, use the standard ticker (e.g., 'AAPL').
2. Execute 'fetch_user_portfolio' to check current exposure to that stock or sector.
3. Execute 'analyze_stock_market' to get the 30-day trend, news sentiment, Expected High, and Expected Low.
4. Synthesize the recommendation using this matrix:
   - Trend UP + News POSITIVE = "Strong Buy". (State the 'Expected High' target).
   - Trend DOWN + News POSITIVE = "Value Buy". (State the 'Expected Low' as the entry point).
   - News NEGATIVE = "Caution/Hold". (Advise waiting for a pattern reversal).
5. If they authorize a purchase, use 'manage_user_portfolio' to add the asset.

SOP 4: SAVINGS GOALS MANAGEMENT
When a user discusses saving for a specific target (e.g., a car, a vacation):
1. Execute 'fetch_user_savings_goals' to check their progress.
2. Calculate the exact amount needed to hit the target and the days remaining.
3. If the user asks to allocate funds, IMMEDIATELY execute 'add_funds_to_goal' with the correct ID and amount. 

SOP 5: MISSING DATA HANDLING
If the user's salary, profession, or budgets are 0, null, or 'Not Specified' in the context:
1. Politely encourage them to update their Profile in the "Settings" menu to unlock algorithmic precision, but provide the best partial answer you can with the data available.
"""
prompt_template = ChatPromptTemplate.from_messages([
    ("system", SYSTEM_PROMPT),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}"), 
])

# --- DEDICATED MODEL FUNCTIONS ---
def get_groq_agent():
    llm = ChatGroq(model=GROQ_MODEL, api_key=GROQ_API_KEY, temperature=0.2)
    agent = create_tool_calling_agent(llm, mcp_tools, prompt_template)
    return AgentExecutor(agent=agent, tools=mcp_tools, verbose=True)

def get_openai_agent():
    llm = ChatOpenAI(model="gpt-4o", api_key=OPENAI_API_KEY, temperature=0.2)
    agent = create_tool_calling_agent(llm, mcp_tools, prompt_template)
    return AgentExecutor(agent=agent, tools=mcp_tools, verbose=True)

def get_gemini_agent():
    llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash", google_api_key=GEMINI_API_KEY, temperature=0.2)
    agent = create_tool_calling_agent(llm, mcp_tools, prompt_template)
    return AgentExecutor(agent=agent, tools=mcp_tools, verbose=True)

def get_claude_agent():
    llm = ChatAnthropic(model="claude-3-haiku-20240307", api_key=ANTHROPIC_API_KEY, temperature=0.2)
    agent = create_tool_calling_agent(llm, mcp_tools, prompt_template)
    return AgentExecutor(agent=agent, tools=mcp_tools, verbose=True)

def get_grok_agent():
    # Grok is OpenAI compatible; we just point the ChatOpenAI client to xAI's base URL
    llm = ChatOpenAI(model="grok-2-latest", api_key=GROK_API_KEY, base_url="https://api.x.ai/v1", temperature=0.2)
    agent = create_tool_calling_agent(llm, mcp_tools, prompt_template)
    return AgentExecutor(agent=agent, tools=mcp_tools, verbose=True)

agent = create_tool_calling_agent(llm, mcp_tools, prompt_template)  
agent_executor = AgentExecutor(agent=agent, tools=mcp_tools, verbose=True)

@app.get("/api/chat/history")
def get_chat_history(user_id: str):
    db = get_db()
    history = list(db.chat_history.find({"user_id": user_id}).sort("created_at", 1))
    
    formatted_history = []
    for h in history:
        raw_msg = h.get("message", "")
        
        # --- SCRUB OLD CORRUPTED GEMINI DATA FROM MONGODB ---
        if isinstance(raw_msg, list):
            clean_msg = "".join(item.get("text", "") if isinstance(item, dict) else str(item) for item in raw_msg)
        elif isinstance(raw_msg, dict):
            clean_msg = raw_msg.get("text", raw_msg.get("content", str(raw_msg)))
        else:
            clean_msg = str(raw_msg)
            
        formatted_history.append({"role": h.get("role"), "text": clean_msg})
        
    return {"status": "success", "data": formatted_history}

@app.post("/api/chat")
async def chat_with_copilot(user_id: str = Form(...), message: str = Form(...), model_choice: str = Form("Groq"), file: UploadFile = File(None)):
    db = get_db()
    try:
        db.chat_history.insert_one({"user_id": user_id, "role": "user", "message": message, "created_at": datetime.now()})
        
        user_profile = db.users.find_one({"_id": ObjectId(user_id)})
        
        profile_context = ""
        if user_profile:
            budgets_dict = json.loads(user_profile.get('custom_budgets', '{}')) 
            budget_str = "\n".join([f"            - {k}: Rs. {float(v)}" for k, v in budgets_dict.items()]) if budgets_dict else "            - No specific limits set."

            profile_context = f"""
            [HIDDEN SYSTEM CONTEXT - DO NOT REPEAT THIS BLOCK TO THE USER]
            User Name: {user_profile.get('name', 'Unknown')}
            Profession: {user_profile.get('profession', 'Unknown')}
            Monthly Salary: Rs. {float(user_profile.get('monthly_salary', 0))}
            Marital Status: {user_profile.get('marital_status', 'Unknown')}
            Family Size: {user_profile.get('family_size', 1)}
            
            Monthly Budget Limits:{budget_str}
            [END HIDDEN CONTEXT]
            """

        file_context = ""
        if file:
            if file.filename.endswith(('.txt', '.csv', '.json', '.md')):
                content = await file.read()
                file_context += f"\nDocument Content:\n{content.decode('utf-8', errors='ignore')}"

        if model_choice == "ChatGPT":
            dynamic_executor = get_openai_agent()
        elif model_choice == "Gemini":
            dynamic_executor = get_gemini_agent()
        elif model_choice == "Claude":
            dynamic_executor = get_claude_agent()
        elif model_choice == "Grok":
            dynamic_executor = get_grok_agent()
        else:
            dynamic_executor = get_groq_agent()
            
        result = dynamic_executor.invoke({
            "input": f"{profile_context}\n\nUser ID: {user_id}.\nUser Message: {message} {file_context}"
        })
        
        # --- BULLETPROOF GEMINI SANITIZER ---
        def extract_clean_text(raw_data):
            if isinstance(raw_data, str):
                return raw_data
            if isinstance(raw_data, list):
                return "".join(extract_clean_text(item) for item in raw_data)
            if isinstance(raw_data, dict):
                # Gemini/LangChain usually hides the actual response under 'text' or 'content'
                if 'text' in raw_data:
                    return extract_clean_text(raw_data['text'])
                if 'content' in raw_data:
                    return extract_clean_text(raw_data['content'])
                return str(raw_data) # Fallback
            return str(raw_data)

        # Force the output to be a flat string, no matter what Gemini returns
        reply = extract_clean_text(result.get('output', ''))
        # ------------------------------------

        db.chat_history.insert_one({"user_id": user_id, "role": "ai", "message": reply, "created_at": datetime.now()})
        
        return {"status": "success", "reply": reply}

    except Exception as e:
        print(f"CRITICAL LANGCHAIN ERROR: {e}")
        
        fallback_reply = (
            "System Alert: Switched to secure Offline Mode due to an API interruption.\n\n"
            "I have manually retrieved your live data directly from the MongoDB database:\n\n"
            "Financial Summary:\n"
        )
        try:
            summary = fetch_user_financial_summary.invoke({"user_id": user_id})
            fallback_reply += f"- Total Income: Rs. {summary['total_income']:,.2f}\n"
            fallback_reply += f"- Total Expenses: Rs. {summary['total_expenses']:,.2f}\n"
            fallback_reply += f"- Net Balance: Rs. {summary['net_balance']:,.2f}\n\n"
            
            goals = fetch_user_savings_goals.invoke({"user_id": user_id})
            fallback_reply += "Savings Goals:\n"
            if goals:
                for g in goals:
                    fallback_reply += f"- {g['goal_name']}: Saved Rs. {float(g['current_amount']):,.2f} of Rs. {float(g['target_amount']):,.2f} (Need Rs. {g['amount_remaining']:,.2f} more by {g['target_date']})\n"
            else:
                fallback_reply += "- No active goals found in the database.\n"
        except Exception as inner_e:
             fallback_reply += "Could not retrieve data at this time."

        db.chat_history.insert_one({"user_id": user_id, "role": "ai", "message": fallback_reply, "created_at": datetime.now()})
        return {"status": "success", "reply": fallback_reply}

# ==========================================
# SAVINGS GOALS ENDPOINTS
# ==========================================
@app.get("/api/goals")
def get_goals(user_id: str):
    db = get_db()
    goals = list(db.goals.find({"user_id": user_id}).sort("target_date", 1))
    return {"status": "success", "data": format_docs(goals)}

@app.post("/api/goals")
def create_goal(goal: GoalCreate):
    db = get_db()
    db.goals.insert_one({
        "user_id": goal.user_id, "goal_name": goal.goal_name, 
        "target_amount": goal.target_amount, "current_amount": 0.0, 
        "target_date": goal.target_date, "created_at": datetime.now()
    })
    return {"status": "success"}

@app.post("/api/goals/{goal_id}/add_funds")
@app.put("/api/goals/{goal_id}/add_funds")
def update_goal_funds_dynamic(goal_id: str, payload: dict):
    add_amount = float(payload.get("add_amount", payload.get("amount", 0)))
    
    print(f"--- ADDING Rs. {add_amount} TO GOAL {goal_id} ---")
    
    if add_amount <= 0:
        return {"status": "error", "message": "No valid amount received."}

    db = get_db()
    try:
        db.goals.update_one({"_id": ObjectId(goal_id)}, {"$inc": {"current_amount": add_amount}})
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": str(e)}
        
@app.delete("/api/goals/{goal_id}")
def delete_goal(goal_id: str):
    db = get_db()
    try:
        db.goals.delete_one({"_id": ObjectId(goal_id)})
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.put("/api/goals/{goal_id}")
def edit_goal(goal_id: str, goal: GoalEdit):
    db = get_db()
    try:
        db.goals.update_one(
            {"_id": ObjectId(goal_id)}, 
            {"$set": {"goal_name": goal.goal_name, "target_amount": goal.target_amount, "target_date": goal.target_date}}
        )
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": str(e)}        

@app.get("/api/analytics")
def get_analytics(user_id: str):
    db = get_db()
    try:
        txns = list(db.transactions.find({"user_id": user_id}).sort("transaction_date", 1))
        
        if not txns:
            return {"status": "success", "data": None}

        daily_flow = {}
        merchants = {}
        category_totals = {}
        income_sources = {"Salary": 0.0, "Other Inflows": 0.0}
        
        total_income = 0.0
        total_expense = 0.0

        for t in txns:
            date_str = str(t['transaction_date'])
            amt = float(t['amount'])
            ttype = t['transaction_type']
            cat = t.get('category', 'Miscellaneous')
            desc = t.get('clean_description', '')
            
            if date_str not in daily_flow:
                daily_flow[date_str] = {"date": date_str, "inflow": 0.0, "outflow": 0.0, "net": 0.0}
            
            if ttype == 'CREDIT':
                daily_flow[date_str]['inflow'] += amt
                total_income += amt
                if "salary" in cat.lower() or "salary" in desc.lower() or "neft" in desc.lower():
                    income_sources["Salary"] += amt
                else:
                    income_sources["Other Inflows"] += amt
            else:
                daily_flow[date_str]['outflow'] += amt
                total_expense += amt
                
                category_totals[cat] = category_totals.get(cat, 0.0) + amt
                
                if amt > 50:
                    merchant_name = str(desc)[:15].strip().upper() 
                    merchants[merchant_name] = merchants.get(merchant_name, 0.0) + amt

        flow_list = []
        for date_str, data in daily_flow.items():
            data['net'] = data['inflow'] - data['outflow']
            flow_list.append(data)
        
        flow_list = sorted(flow_list, key=lambda x: x['date'])
        
        current_balance = total_income - total_expense
        days_active = len(flow_list) if len(flow_list) > 0 else 1
        avg_daily_burn = total_expense / days_active
        
        runway_days = int(current_balance / avg_daily_burn) if avg_daily_burn > 0 else 0
        
        top_merchants = [{"name": k, "amount": v} for k, v in sorted(merchants.items(), key=lambda item: item[1], reverse=True)[:6]]
        cat_data = [{"name": k, "value": v} for k, v in category_totals.items()]
        inc_data = [{"name": k, "value": v} for k, v in income_sources.items() if v > 0]

        return {
            "status": "success",
            "kpis": {
                "current_balance": current_balance,
                "avg_daily_burn": avg_daily_burn,
                "runway_days": runway_days
            },
            "flow_data": flow_list,
            "top_merchants": top_merchants,
            "category_data": cat_data,
            "income_data": inc_data
        }
    except Exception as e:
        print(f"ANALYTICS ERROR: {e}")
        return {"status": "error", "message": str(e)}

@app.get("/api/analytics/market_comparison")
def get_market_comparison(user_id: str):
    db = get_db()
    try:
        holdings = list(db.portfolio_holdings.find({"user_id": user_id}))
        if not holdings:
            return {"status": "success", "data": {}}

        # 1. Automatically group holdings by their Country/Region based on ticker suffix
        regions = {}
        for h in holdings:
            sym = str(h.get('asset_symbol', '')).upper()
            if not sym: continue
            
            if sym.endswith('.NS') or sym.endswith('.BO'):
                reg, bench, b_name = "Indian Market", "^NSEI", "NIFTY 50"
            elif sym.endswith('.SS') or sym.endswith('.SZ'):
                reg, bench, b_name = "Chinese Market", "000001.SS", "SSE Composite"
            elif sym.endswith('.L'):
                reg, bench, b_name = "UK Market", "^FTSE", "FTSE 100"
            elif sym.endswith('.TO'):
                reg, bench, b_name = "Canadian Market", "^GSPTSE", "S&P/TSX"
            else:
                # Standard tickers with no suffix are typically US Equities
                reg, bench, b_name = "US Market", "^GSPC", "S&P 500"

            if reg not in regions:
                regions[reg] = {"benchmark": bench, "benchmark_name": b_name, "holdings": []}
            regions[reg]["holdings"].append(h)

        result_data = {}
        
        # 2. Process historical percentage growth for each region independently
        for reg, rdata in regions.items():
            bench_ticker = yf.Ticker(rdata["benchmark"])
            bench_hist = bench_ticker.history(period="1mo")
            
            if bench_hist.empty: 
                continue

            bench_start = float(bench_hist['Close'].iloc[0])
            
            # Fetch 30-day history for all user stocks in this region
            holding_hists = {}
            for h in rdata["holdings"]:
                sym = h['asset_symbol']
                h_hist = yf.Ticker(sym).history(period="1mo")
                if not h_hist.empty:
                    holding_hists[sym] = {
                        "hist": h_hist['Close'],
                        "qty": float(h.get('quantity', 0))
                    }

            chart_data = []
            
            # Loop through the market dates to build the comparison chart
            for date, row in bench_hist.iterrows():
                date_str = date.strftime('%b %d')
                
                # Market Growth %
                b_pct = ((float(row['Close']) - bench_start) / bench_start) * 100 if bench_start > 0 else 0

                port_start_value = 0.0
                port_current_value = 0.0

                for sym, hd in holding_hists.items():
                    p_start = float(hd["hist"].iloc[0])
                    
                    # Handle timezone/holiday mismatches by getting the last available price on or before this date
                    past_prices = hd["hist"][hd["hist"].index <= date]
                    p_curr = float(past_prices.iloc[-1]) if not past_prices.empty else p_start

                    port_start_value += p_start * hd["qty"]
                    port_current_value += p_curr * hd["qty"]

                # Portfolio Growth %
                p_pct = ((port_current_value - port_start_value) / port_start_value) * 100 if port_start_value > 0 else 0

                chart_data.append({
                    "date": date_str,
                    "Benchmark": round(b_pct, 2),
                    "Portfolio": round(p_pct, 2)
                })

            result_data[reg] = {
                "benchmark_name": rdata["benchmark_name"],
                "chart_data": chart_data
            }

        return {"status": "success", "data": result_data}
        
    except Exception as e:
        print(f"MARKET COMPARISON ERROR: {e}")
        return {"status": "error", "message": str(e)}        

# ==========================================
# LOANS & DEBT MANAGEMENT ENDPOINTS
# ==========================================
@app.get("/api/loans")
def get_loans(user_id: str):
    db = get_db()
    loans = list(db.loans.find({"user_id": user_id}).sort("start_date", 1))
    return {"status": "success", "data": format_docs(loans)}

@app.post("/api/loans")
def create_loan(loan: LoanCreate):
    db = get_db()
    db.loans.insert_one(loan.dict() | {"outstanding_balance": loan.principal_amount, "total_interest_paid": 0.0})
    return {"status": "success"}

@app.post("/api/loans/pay")
def pay_loan_emi(payment: LoanPayment):
    db = get_db()
    db.loans.update_one(
        {"_id": ObjectId(payment.loan_id)}, 
        {"$inc": {"outstanding_balance": -payment.payment_amount, "total_interest_paid": payment.interest_amount}}
    )
    return {"status": "success"}

@app.delete("/api/loans/{loan_id}")
def delete_loan(loan_id: str):
    db = get_db()
    db.loans.delete_one({"_id": ObjectId(loan_id)})
    return {"status": "success"}

@app.put("/api/loans/{loan_id}")
def edit_loan(loan_id: str, loan: LoanEdit):
    db = get_db()
    old = db.loans.find_one({"_id": ObjectId(loan_id)})
    if not old:
        return {"status": "error", "message": "Loan not found"}
        
    old_principal = float(old.get('principal_amount', 0))
    principal_difference = loan.principal_amount - old_principal

    db.loans.update_one(
        {"_id": ObjectId(loan_id)}, 
        {
            "$set": loan.dict(), 
            "$inc": {"outstanding_balance": principal_difference}
        }
    )
    return {"status": "success"}

# ==========================================
# PDF REPORT GENERATOR
# ==========================================
@app.get("/api/report/download/{user_id}")
async def download_financial_report(user_id: str):
    try:
        db = get_db()
        
        # 1. Fetch ALL User Data Context
        user = db.users.find_one({"_id": ObjectId(user_id)})
        user_name = user.get("name", "Valued User") if user else "Valued User"

        txns = list(db.transactions.find({"user_id": user_id}))
        holdings = list(db.portfolio_holdings.find({"user_id": user_id}))
        loans = list(db.loans.find({"user_id": user_id}))

        # 2. Calculate Advanced Metrics
        total_income = sum(t['amount'] for t in txns if t.get('transaction_type') == 'CREDIT')
        total_expense = sum(t['amount'] for t in txns if t.get('transaction_type') == 'DEBIT')
        net_cash = total_income - total_expense

        # FIXED: Now strictly uses 'quantity', 'current_market_price', and 'outstanding_balance'
        portfolio_value = sum(float(h.get('quantity', 0)) * float(h.get('current_market_price', h.get('average_buy_price', 0))) for h in holdings)
        total_debt = sum(float(l.get('outstanding_balance', l.get('principal_amount', 0))) for l in loans)

        # Find Top Expense Categories
        expenses = [t for t in txns if t.get('transaction_type') == 'DEBIT']
        cat_totals = {}
        for e in expenses:
            cat = e.get('category', 'Miscellaneous')
            cat_totals[cat] = cat_totals.get(cat, 0) + e['amount']
        sorted_cats = sorted(cat_totals.items(), key=lambda x: x[1], reverse=True)
        top_cats_str = ", ".join([f"{k} (Rs.{v:,.0f})" for k,v in sorted_cats[:4]]) if sorted_cats else "None yet"

        # 3. Generate AI Insights dynamically!
        ai_prompt = f"""You are a top-tier Wealth Advisor writing an executive summary for a client's financial report.
        Client Name: {user_name}
        Total Income: Rs. {total_income:,.0f}
        Total Expenses: Rs. {total_expense:,.0f}
        Net Cash Flow: Rs. {net_cash:,.0f}
        Investment Portfolio Value: Rs. {portfolio_value:,.0f}
        Total Outstanding Debt: Rs. {total_debt:,.0f}
        Top Expense Categories: {top_cats_str}
        
        Write a concise, highly professional 3-paragraph executive summary:
        1. An assessment of their cash flow and spending behavior.
        2. An evaluation of their wealth accumulation (assets vs. debt).
        3. 2-3 actionable, personalized recommendations for improving their financial trajectory.
        
        CRITICAL: Output plain text only. Do not use Markdown, hashtags, or asterisks. Keep it under 250 words.
        """
        
        try:
            print(f"[AI] Generating Personalized Report Insights for {user_name}...")
            response = raw_groq_client.chat.completions.create(
                model=GROQ_MODEL,
                messages=[{"role": "user", "content": ai_prompt}],
                temperature=0.3
            )
            ai_insights = response.choices[0].message.content.strip()
        except Exception as e:
            print("AI Insight generation failed:", e)
            ai_insights = "AI Insights are currently unavailable. Please review the data tables below for your financial summary."

        # 4. Generate Beautiful PDF using ReportLab
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
        elements = []
        
        styles = getSampleStyleSheet()
        title_style = styles['Title']
        title_style.textColor = colors.HexColor("#1e3a8a")
        h1_style = styles['Heading1']
        h1_style.textColor = colors.HexColor("#3b82f6")
        h2_style = styles['Heading2']
        h2_style.textColor = colors.HexColor("#0f172a")
        
        normal_style = styles['Normal']
        normal_style.fontSize = 11
        normal_style.leading = 16
        normal_style.textColor = colors.HexColor("#334155")

        # HEADER
        elements.append(Paragraph(f"FinCoPilot Intelligence Report", title_style))
        elements.append(Paragraph(f"Prepared for: <b>{user_name}</b> | Generated: {datetime.now().strftime('%d %b %Y, %I:%M %p')}", normal_style))
        elements.append(Spacer(1, 20))

        # AI EXECUTIVE SUMMARY
        elements.append(Paragraph("AI Executive Summary & Recommendations", h1_style))
        for para in ai_insights.split('\n'):
            if para.strip():
                elements.append(Paragraph(para.strip(), normal_style))
                elements.append(Spacer(1, 10))
        elements.append(Spacer(1, 15))

        # OVERVIEW METRICS TABLE
        elements.append(Paragraph("Financial Health Overview", h1_style))
        overview_data = [
            ["Metric", "Value (Rs.)"],
            ["Total Inflow (Income)", f"Rs. {total_income:,.2f}"],
            ["Total Outflow (Expenses)", f"Rs. {total_expense:,.2f}"],
            ["Net Cash Flow", f"Rs. {net_cash:,.2f}"],
            ["Total Asset Value", f"Rs. {portfolio_value:,.2f}"],
            ["Total Outstanding Debt", f"Rs. {total_debt:,.2f}"]
        ]
        
        t_overview = Table(overview_data, colWidths=[250, 150])
        t_overview.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#3b82f6")),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor("#f8fafc")),
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor("#e2e8f0"))
        ]))
        elements.append(t_overview)
        elements.append(Spacer(1, 25))

        # TOP EXPENSES TABLE
        if sorted_cats:
            elements.append(Paragraph("Top Expense Categories", h2_style))
            exp_data = [["Category", "Total Spent (Rs.)"]]
            for cat, amt in sorted_cats[:5]:
                exp_data.append([cat, f"Rs. {amt:,.2f}"])
                
            t_exp = Table(exp_data, colWidths=[250, 150])
            t_exp.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#64748b")),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor("#e2e8f0"))
            ]))
            elements.append(t_exp)

        # Build PDF
        doc.build(elements)
        buffer.seek(0)
        
        return StreamingResponse(
            buffer, 
            media_type="application/pdf", 
            headers={"Content-Disposition": f"attachment; filename=FinCoPilot_AI_Wealth_Report.pdf"}
        )
        
    except Exception as e:
        print("Report Generation Error:", e)
        raise HTTPException(status_code=500, detail=f"Could not generate AI report: {str(e)}")

@app.get("/api/portfolio")
def get_live_portfolio(user_id: str):
    db = get_db()
    try:
        holdings = list(db.portfolio_holdings.find({"user_id": user_id}))
        formatted = []
        for h in holdings:
            h = format_doc(h)
            symbol = h.get('asset_symbol')
            asset_class = h.get('asset_class')
            
            live = get_live_price(symbol, asset_class)
            
            if live:
                h['current_market_price'] = live
                h['profit_loss'] = (float(h['current_market_price']) - float(h.get('average_buy_price', 0))) * float(h.get('quantity', 0))
            formatted.append(h)
                
        return {"status": "success", "data": formatted}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/portfolio/add")
def add_portfolio_asset(asset: PortfolioAdd):
    try:
        result = manage_user_portfolio.invoke({
            "user_id": asset.user_id,
            "action": "ADD",
            "symbol": asset.symbol,
            "qty": asset.qty,
            "price": asset.price,
            "category": asset.category
        })
        return {"status": "success", "message": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/portfolio/delete/{holding_id}")
def delete_portfolio_asset_by_id(holding_id: str):
    db = get_db()
    try:
        db.portfolio_holdings.delete_one({"_id": ObjectId(holding_id)})
        return {"status": "success", "message": "Exact asset row deleted."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))     

@app.put("/api/portfolio/{holding_id}")
def edit_portfolio(holding_id: str, holding: PortfolioEdit):
    db = get_db()
    try:
        db.portfolio_holdings.update_one(
            {"_id": ObjectId(holding_id)}, 
            {"$set": {"quantity": holding.quantity, "average_buy_price": holding.price}}
        )
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/api/news/{user_id}")
def get_personalized_news(user_id: str):
    db = get_db()
    try:
        # Get unique symbols
        holdings = list(db.portfolio_holdings.find({"user_id": user_id}, {"asset_symbol": 1}))
        symbols = list(set([h.get('asset_symbol') for h in holdings if h.get('asset_symbol')]))
        
        article_pool = []
        end_date = datetime.now().strftime('%Y-%m-%d')
        start_date = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d') 

        if symbols:
            for symbol in symbols[:5]:
                clean_symbol = symbol.split('.')[0] 
                url = f"https://finnhub.io/api/v1/company-news?symbol={clean_symbol}&from={start_date}&to={end_date}&token={FINNHUB_API_KEY}"
                response = requests.get(url)
                
                if response.status_code == 200:
                    articles = response.json()
                    for article in articles[:15]:
                        article_pool.append({
                            "headline": article.get("headline"),
                            "image": article.get("image"),
                            "url": article.get("url"),
                            "source": article.get("source"),
                            "tag": clean_symbol
                        })

        if len(article_pool) < 10:
            url = f"https://finnhub.io/api/v1/news?category=general&token={FINNHUB_API_KEY}"
            response = requests.get(url)
            if response.status_code == 200:
                articles = response.json()
                for article in articles[:30]:
                    article_pool.append({
                        "headline": article.get("headline"),
                        "image": article.get("image"),
                        "url": article.get("url"),
                        "source": article.get("source"),
                        "tag": "Market"
                    })

        random.shuffle(article_pool)
        final_daily_feed = article_pool[:10]

        return {"status": "success", "data": final_daily_feed}
    except Exception as e:
        return {"status": "error", "message": str(e)}

# ==========================================
# ACCOUNT DELETION ENDPOINT
# ==========================================
@app.delete("/api/users/{user_id}")
def delete_user_account(user_id: str):
    print(f"--- DELETING ACCOUNT FOR USER ID: {user_id} ---")
    db = get_db()
    try:
        db.transactions.delete_many({"user_id": user_id})
        db.goals.delete_many({"user_id": user_id})
        db.chat_history.delete_many({"user_id": user_id})
        db.portfolio_holdings.delete_many({"user_id": user_id})
        db.loans.delete_many({"user_id": user_id})
        
        db.users.delete_one({"_id": ObjectId(user_id)})
        
        return {"status": "success", "message": "Account and all associated data permanently deleted."}
    except Exception as e:
        print(f"Delete Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))       

@app.get("/api/2fa/setup")
def generate_2fa_secret(email: str):
    secret = pyotp.random_base32()
    uri = pyotp.totp.TOTP(secret).provisioning_uri(name=email, issuer_name="FinCoPilot")
    
    qr = qrcode.QRCode(version=1, box_size=10, border=4)
    qr.add_data(uri)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    buffered = BytesIO()
    img.save(buffered, format="PNG")
    img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
    
    return {
        "status": "success", 
        "secret": secret, 
        "qr_code": f"data:image/png;base64,{img_str}"
    }    

# ==========================================
# SMART NOTIFICATION ENGINE (LOANS & BUDGETS)
# ==========================================
@app.get("/api/notifications")
def get_notifications(user_id: str):
    db = get_db()
    notifications = []
    
    try:
        # 1. BUDGET CHECK
        user_data = db.users.find_one({"_id": ObjectId(user_id)})
        
        if user_data and user_data.get('custom_budgets'):
            budgets = json.loads(user_data.get('custom_budgets', '{}'))
            
            pipeline = [
                {"$match": {"user_id": user_id, "transaction_type": "DEBIT"}},
                {"$group": {"_id": "$category", "spent": {"$sum": "$amount"}}}
            ]
            monthly_spending = list(db.transactions.aggregate(pipeline))
            
            for item in monthly_spending:
                cat = item['_id']
                spent = float(item['spent'])
                
                if cat in budgets:
                    limit = float(budgets[cat])
                    if limit > 0 and spent > limit:
                        notifications.append({
                            "id": f"budget_exceeded_{cat}",
                            "type": "budget_danger",
                            "title": "Budget Exceeded!",
                            "message": f"You spent Rs. {spent:,.0f} on {cat}, exceeding your limit of Rs. {limit:,.0f}."
                        })
                    elif limit > 0 and spent >= limit * 0.8:
                        notifications.append({
                            "id": f"budget_warning_{cat}",
                            "type": "budget_warning",
                            "title": "Nearing Budget Limit",
                            "message": f"You have spent {(spent/limit)*100:.0f}% of your {cat} budget."
                        })

        # 2. LOAN CHECK
        loans = list(db.loans.find({"user_id": user_id, "outstanding_balance": {"$gt": 0}}))
        
        tomorrow = datetime.now() + timedelta(days=1)
        tomorrow_day = tomorrow.day
        
        for loan in loans:
            start_date = loan.get('start_date', '')
            try:
                loan_day = int(str(start_date).split('-')[2])
                if loan_day == tomorrow_day:
                    fixed_principal = float(loan.get('principal_amount', 0)) / int(loan.get('duration_months', 1))
                    current_interest = float(loan.get('outstanding_balance', 0)) * (float(loan.get('interest_rate', 0)) / 12 / 100)
                    current_emi = fixed_principal + current_interest
                    
                    notifications.append({
                        "id": f"loan_{str(loan['_id'])}",
                        "type": "loan_reminder",
                        "title": "EMI Due Tomorrow!",
                        "message": f"Your current EMI of Rs. {current_emi:,.0f} for '{loan.get('loan_name', '')}' will be deducted tomorrow."
                    })
            except Exception as e:
                pass

        return {"status": "success", "data": notifications}
    except Exception as e:
        print("Notification Error:", e)
        return {"status": "error"}

# --- AI ANALYTICS INSIGHTS ENGINE ---
class AnalyticsInsightRequest(BaseModel):
    summary: str

@app.post("/api/analytics/insights")
def generate_ai_analytics_insights(req: AnalyticsInsightRequest):
    try:
        prompt = f"""You are an elite AI wealth advisor. Analyze this financial data:
        {req.summary}
        
        Provide EXACTLY 3 actionable insights based on these metrics:
        1. 'success': What they are doing well (e.g., low debt, good runway).
        2. 'warning': A risk, high expense area, or debt concern.
        3. 'info': A strategic growth, investment, or optimization move.
        
        Do not use any emojis in your response. Return ONLY a valid JSON object matching this structure:
        {{
          "insights": [
            {{ "type": "success", "title": "Short Title", "description": "1-2 sentences of deep analysis" }},
            {{ "type": "warning", "title": "Short Title", "description": "1-2 sentences of deep analysis" }},
            {{ "type": "info", "title": "Short Title", "description": "1-2 sentences of deep analysis" }}
          ]
        }}
        """
        
        print("[AI] Generating Dynamic Analytics Insights...")
        response = raw_groq_client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            response_format={"type": "json_object"}
        )
        
        result = json.loads(response.choices[0].message.content)
        return {"status": "success", "insights": result.get("insights", [])}
    except Exception as e:
        print("Insight Error:", e)
        return {"status": "error", "insights": []}
        
# ==========================================
# PRODUCTION FRONTEND SERVER
# ==========================================
frontend_dist = os.path.join(os.path.dirname(__file__), "..", "frontend", "dist")

if os.path.exists(os.path.join(frontend_dist, "assets")):
    app.mount("/assets", StaticFiles(directory=os.path.join(frontend_dist, "assets")), name="assets")

@app.get("/{full_path:path}")
async def serve_react(full_path: str):
    if full_path.startswith("api/"):
        raise HTTPException(status_code=404, detail="API route not found")

    index_path = os.path.join(frontend_dist, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    else:
        raise HTTPException(status_code=404, detail="React build not found. Did you run 'npm run build'?")

# ==========================================
# SERVER RUNNER (FOR RENDER DEPLOYMENT)
# ==========================================
if __name__ == "__main__":
    # Render provides the PORT environment variable. Default to 10000 if not found.
    port = int(os.environ.get("PORT", 10000))
    print(f"Starting server on 0.0.0.0:{port}...")
    uvicorn.run("main:app", host="0.0.0.0", port=port)
